﻿namespace Task.Data.Entites
{
    public class BaseEntity<T>
    {
        public virtual T Id { get; set; }
    }
}
