﻿namespace Mask.Dto
{
    public class BookDto
    {
        public string BookName { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }
        public int AuthorId { get; set; }
    }
}
